function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5xscY5yooFr":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

